/**
 * *******************************************************
 * Simula
 * simula.ui
 * InterfaceType.scala
 * (c)Simula on 31 oct. 2013 13:01:50
 * By JC
 * Update 31 oct. 2013 13:01:50
 *
 * *******************************************************
 */
package main.scala.simula.ui

/**
 * @author JC
 *
 */
object InterfaceType extends Enumeration {

  type InterfaceType = Value
  val TEXT, CLI, GUI, NUI = Value
}