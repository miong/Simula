/**
 * *******************************************************
 * simula-project
 * main.scala.simula.ui
 * UserListenerInterface.scala
 * (c)simula-project on 18 nov. 2013 10:18:57
 * By Scarpe
 * Update 18 nov. 2013 10:18:57
 * *******************************************************
 */
package main.scala.simula.ui

/**
 * @author Scarpe
 *
 */
trait UserListenerInterface {

}