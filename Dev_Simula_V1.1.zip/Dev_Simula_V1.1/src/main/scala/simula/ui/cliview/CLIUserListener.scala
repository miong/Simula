/**
 * *******************************************************
 * simula-project
 * main.scala.simula.ui.cliview
 * CLIUserListener.scala
 * (c)simula-project on 18 nov. 2013 10:38:47
 * By Scarpe
 * Update 18 nov. 2013 10:38:47
 * *******************************************************
 */
package main.scala.simula.ui.cliview

import main.scala.simula.common._
import main.scala.simula.ui._
/**
 * @author Scarpe
 *
 */
trait CLIUserListener extends UserListenerInterface {

}