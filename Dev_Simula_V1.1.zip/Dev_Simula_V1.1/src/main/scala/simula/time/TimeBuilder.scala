/**
 * *******************************************************
 * Simula
 *
 * test2.scala
 * (c)Simula on 30 oct. 2013 11:19:05
 * By Scarpe
 * Update 30 oct. 2013 11:19:05
 * *******************************************************
 */
/**
 * @author Scarpe
 *
 */
package main.scala.simula.time

class TimeBuilder extends TimeBuilderInterface {

  def build(): Time = {
    return new Time(new Clock(), new MonthFilter(), new YearFilter());
  }

}