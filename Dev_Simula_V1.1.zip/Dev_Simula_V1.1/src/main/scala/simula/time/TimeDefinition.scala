/**
 * *******************************************************
 * Simula
 * simula.model.time
 * TimeDefinition.scala
 * (c)Simula on 5 nov. 2013 18:53:06
 * By Bubul
 * Update 5 nov. 2013 18:53:06
 * *******************************************************
 */
package main.scala.simula.time

/**
 * @author Bubul
 *
 */
object TimeDefinition {
  val n_month: Int = 10
  val n_year: Int = 12 * n_month
}