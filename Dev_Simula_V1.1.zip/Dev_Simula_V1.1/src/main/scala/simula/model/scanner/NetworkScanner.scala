/**
 * *******************************************************
 * Simula
 * scanner
 * NetworkScanner.scala
 * (c)Simula on 30 oct. 2013 11:22:02
 * By Bubul
 * Update 30 oct. 2013 11:22:02
 * *******************************************************
 */
package main.scala.simula.model.scanner

/**
 * @author Bubul
 *
 */
trait NetworkScanner {

}

