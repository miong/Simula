/**
 * *******************************************************
 * Simula
 * scanner
 * Test.scala
 * (c)Simula on 30 oct. 2013 11:17:58
 * By Bubul
 * Update 30 oct. 2013 11:17:58
 * *******************************************************
 */
package main.scala.simula.model.scanner

import main.scala.simula.model.city._
import main.scala.simula.model._
import main.scala.simula.common.Location
import main.scala.simula.common.Size

class GeneralScanner extends GeneralScannerInterface
  with DisplayScanner
  with CriminalityScanner
  with NetworkScanner
  with PolutionScanner
  with PopulationScanner
  with InfrastructuresScanner {

  def scanInfrastructures(loc:Location,siz:Size):Set[Infrastructure] = {
    return this.getInfrastructures(model, loc, siz)
  }
  
}
