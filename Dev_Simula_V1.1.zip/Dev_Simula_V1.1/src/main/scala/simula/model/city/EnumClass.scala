/**
 * *******************************************************
 * SimulaGame
 * main.scala.simula.model.city
 * EnumClasse.scala
 * (c)SimulaGame on 17 nov. 2013 20:18:20
 * By ken
 * Update 17 nov. 2013 20:18:20
 * *******************************************************
 */
package main.scala.simula.model.city

/**
 * @author ken
 *
 */
object EnumClass extends Enumeration{
	type EnumClass = Value
	val RICH,POOR,MEDIUM = Value
}