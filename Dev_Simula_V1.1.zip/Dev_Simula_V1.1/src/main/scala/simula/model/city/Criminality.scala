/**
 * *******************************************************
 * SimulaGame
 * main.scala.simula.model.city
 * Criminality.scala
 * (c)SimulaGame on 17 nov. 2013 20:16:20
 * By ken
 * Update 17 nov. 2013 20:16:20
 * *******************************************************
 */
package main.scala.simula.model.city

/**
 * @author ken
 *
 */
class Criminality extends Mesure{

}