/**
 * *******************************************************
 * SimulaGame
 * main.scala.simula.model.city
 * EconomicEvaluation.scala
 * (c)SimulaGame on 17 nov. 2013 20:14:50
 * By ken
 * Update 17 nov. 2013 20:14:50
 * *******************************************************
 */
package main.scala.simula.model.city

/**
 * @author ken
 *
 */
class EconomicEvaluation extends Mesure{
	
}