/**
 * *******************************************************
 * Simula_Dev1.0
 * main.scala.simula.model.city
 * Flux.scala
 * (c)Simula_Dev1.0 on 18 nov. 2013 11:16:16
 * By Bubul
 * Update 18 nov. 2013 11:16:16
 * *******************************************************
 */
package main.scala.simula.model.city

/**
 * @author Bubul
 *
 */
class Flux extends Mesure{

}