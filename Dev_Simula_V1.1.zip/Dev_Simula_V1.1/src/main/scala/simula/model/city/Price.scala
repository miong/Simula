/**
 * *******************************************************
 * Simula_Dev1.0
 * main.scala.simula.model.city
 * Price.scala
 * (c)Simula_Dev1.0 on 18 nov. 2013 11:16:56
 * By Bubul
 * Update 18 nov. 2013 11:16:56
 * *******************************************************
 */
package main.scala.simula.model.city

/**
 * @author Bubul
 *
 */
class Price extends Mesure{

}