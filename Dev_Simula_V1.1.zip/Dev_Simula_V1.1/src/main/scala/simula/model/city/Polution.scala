/**
 * *******************************************************
 * SimulaGame
 * main.scala.simula.model.city
 * Polution.scala
 * (c)SimulaGame on 17 nov. 2013 20:16:01
 * By ken
 * Update 17 nov. 2013 20:16:01
 * *******************************************************
 */
package main.scala.simula.model.city

/**
 * @author ken
 *
 */
class Polution extends Mesure{

}