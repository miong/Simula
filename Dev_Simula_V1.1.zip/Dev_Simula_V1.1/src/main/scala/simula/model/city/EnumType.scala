/**
 * *******************************************************
 * SimulaGame
 * main.scala.simula.model.city
 * EnumType.scala
 * (c)SimulaGame on 17 nov. 2013 19:33:01
 * By ken
 * Update 17 nov. 2013 19:33:01
 * *******************************************************
 */
package main.scala.simula.model.city

/**
 * @author ken
 *
 */
object EnumType extends Enumeration{
	type EnumType = Value
	val AREA = Value
}