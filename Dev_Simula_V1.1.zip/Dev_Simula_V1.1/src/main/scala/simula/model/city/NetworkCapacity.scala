/**
 * *******************************************************
 * SimulaGame
 * main.scala.simula.model.city
 * NetworkCapacity.scala
 * (c)SimulaGame on 17 nov. 2013 20:20:13
 * By ken
 * Update 17 nov. 2013 20:20:13
 * *******************************************************
 */
package main.scala.simula.model.city

/**
 * @author ken
 *
 */
class NetworkCapacity extends Mesure{

}