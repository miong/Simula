/**
 * *******************************************************
 * Simula
 * main.scala.simula.model.city
 * SocialClasseType.scala
 * (c)SimulaGame on 17 nov. 2013 20:18:20
 * By ken
 * Update 17 nov. 2013 20:18:20
 * *******************************************************
 */
package main.scala.simula.common

/**
 * @author ken
 *
 */
object SocialClassType extends Enumeration {
  type SocialClassType = Value
  val RICH, POOR, MEDIUM = Value
}