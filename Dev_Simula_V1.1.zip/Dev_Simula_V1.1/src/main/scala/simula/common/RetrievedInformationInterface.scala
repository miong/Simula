/**
 * *******************************************************
 * Simula
 * scanner
 * RetreivedInformationInterface.scala
 * (c)Simula on 1 nov. 2013 13:20:49
 * By Bubul
 * Update 1 nov. 2013 13:20:49
 * *******************************************************
 */
package main.scala.simula.common

/**
 * @author Bubul
 *
 */
abstract class RetrievedInformationInterface {
  def getNumberOfCitizen(): Integer;
  def getGlobalPolution(): Integer;
  def getGlobalCriminality(): Integer;
  def getViewables(): Set[Viewable];
  def getLocationOfInfos():Location;
  def getSizeOfInfos():Size;
}